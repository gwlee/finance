from flask import Flask, render_template, request, jsonify
from pymongo import MongoClient
from datetime import datetime, timedelta
import pandas as pd
import subprocess
import os

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
db = client["finance_db"]

COLLECTIONS = {
    "korean_stocks": "korean_stocks",
    "us_stocks": "us_stocks",
    "indices": "indices",
    "currencies": "currencies"
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/viewer/<category>")
def viewer(category):
    return render_template("viewer.html", category=category)

@app.route("/comparison")
def comparison():
    return render_template("comparison.html")

@app.route("/admin")
def admin():
    return render_template("admin.html")

@app.route("/api/search")
def api_search():
    q = request.args.get("q", "")
    category = request.args.get("category", "korean_stocks")
    col = db["ticker_metadata"]
    regex = {"$regex": q, "$options": "i"}
    results = list(col.find({
        "$or": [{"ticker": regex}, {"name": regex}],
        "market_type": category
    }, {"_id": 0}).limit(10))
    return jsonify(results)

@app.route("/api/data")
def api_data():
    ticker = request.args.get("ticker")
    category = request.args.get("category")
    col = db[COLLECTIONS[category]]
    data = list(col.find({"symbol": ticker}, {"_id": 0}).sort("date", 1))
    df = pd.DataFrame(data)
    df["date"] = pd.to_datetime(df["date"])
    df = df.dropna()
    return df.to_dict(orient="records")

@app.route("/api/update", methods=["POST"])
def api_update():
    script_map = {
        "korean_stocks": "update_kr.py",
        "us_stocks": "update_us.py",
        "indices": "update_index.py",
        "currencies": "update_currency.py"
    }
    category = request.json.get("category")
    script = script_map.get(category)
    if script and os.path.exists(f"update_scripts/{script}"):
        subprocess.Popen(["python", f"update_scripts/{script}"])
        return jsonify({"status": "started"})
    return jsonify({"status": "error"})

@app.route("/api/ticker_metadata")
def api_ticker_metadata():
    col = db["ticker_metadata"]
    page = int(request.args.get("page", 1))
    per_page = 50
    skip = (page - 1) * per_page
    data = list(col.find({}, {"_id": 0}).skip(skip).limit(per_page))
    total = col.count_documents({})
    return jsonify({"data": data, "total": total, "page": page})

@app.route("/api/ticker_update", methods=["POST"])
def api_ticker_update():
    updates = request.json.get("updates", [])
    col = db["ticker_metadata"]
    for u in updates:
        col.update_one({"ticker": u["ticker"]}, {"$set": {"name": u["name"], "market_type": u["market_type"]}})
    return jsonify({"status": "updated"})

if __name__ == "__main__":
    app.run(debug=True)