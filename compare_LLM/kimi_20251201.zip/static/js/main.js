async function loadChart(ticker, days) {
    const category = "{{ category }}";
    const res = await fetch(`/api/data?category=${category}&ticker=${ticker}`);
    let data = await res.json();
    if (days !== "max") {
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        data = data.filter(d => new Date(d.date) >= cutoff);
    }
    const dates = data.map(d => d.date);
    const close = data.map(d => d.close);
    const open = data.map(d => d.open);
    const high = data.map(d => d.high);
    const low = data.map(d => d.low);

    const trace = {
        x: dates,
        close: close,
        open: open,
        high: high,
        low: low,
        type: 'candlestick',
        name: ticker
    };

    const layout = {
        title: ticker,
        xaxis: { title: 'Date' },
        yaxis: { title: 'Price' }
    };

    Plotly.newPlot('chart', [trace], layout);
}

async function loadComparison(symbols) {
    const traces = [];
    for (const s of symbols) {
        const res = await fetch(`/api/data?category=us_stocks&ticker=${s}`);
        let data = await res.json();
        const base = data[0]?.close || 1;
        const dates = data.map(d => d.date);
        const normalized = data.map(d => (d.close / base - 1) * 100);
        traces.push({
            x: dates,
            y: normalized,
            mode: 'lines',
            name: s
        });
    }
    Plotly.newPlot('chart', traces, { title: "정규화 비교 (%)", xaxis: { title: "Date" }, yaxis: { title: "%" } });
}