import subprocess
subprocess.run(["python", "02.mongodb_update_fix.py"])