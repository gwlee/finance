from flask import Flask, render_template, request, jsonify, send_from_directory, url_for
from pymongo import MongoClient
from bson.json_util import dumps
from datetime import datetime, timedelta
import subprocess, os

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = os.environ.get("DB_NAME", "finance_db")

app = Flask(__name__, static_folder="static", template_folder="templates")

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# --- Helpers ---
def collection_for_market(market):
    mapping = {
        "korean": "korean_stocks",
        "us": "us_stocks",
        "indices": "indices",
        "currencies": "currencies"
    }
    return db[mapping.get(market, "korean_stocks")]

# --- Routes ---
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/viewer/<market>")
def viewer(market):
    # market in ["korean","us","indices","currencies"]
    return render_template("viewer.html", market=market)

@app.route("/admin")
def admin():
    return render_template("admin.html")

# API: search ticker_metadata
@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    if not q:
        return jsonify([])
    coll = db["ticker_metadata"]
    # regex search in ticker or name (case-insensitive)
    regex = {"$regex": q, "$options": "i"}
    cursor = coll.find({"$or":[{"ticker": regex}, {"name": regex}]}, {"_id":0}).limit(50)
    results = list(cursor)
    return jsonify(results)

# API: data retrieval for charting
@app.route("/api/data/<market>/<ticker>")
def api_data(market, ticker):
    period = request.args.get("period", "1mo")  # simple period param, e.g., 1mo, 3mo, 1y
    coll = collection_for_market(market)
    # convert yfinance-like ticker format if needed (no heavy logic here).
    # period parsing to get earliest date
    now = datetime.utcnow()
    if period.endswith("mo"):
        try:
            months = int(period[:-2])
        except:
            months = 1
        days = months * 30
        start = now - timedelta(days=days)
    elif period.endswith("y"):
        try:
            years = int(period[:-1])
        except:
            years = 1
        start = now - timedelta(days=365*years)
    else:
        # default 1 month
        start = now - timedelta(days=30)

    cursor = coll.find({"symbol": {"$regex": f"^{ticker}$", "$options": "i"}, "date": {"$gte": start}}, {"_id":0}).sort("date", 1)
    data = list(cursor)
    return dumps(data)  # bson json_util

# Admin: trigger update scripts (spawns subprocess)
@app.route("/admin/update/<target>", methods=["POST"])
def admin_update(target):
    # target in: kr, us, indices, currencies
    script_map = {
        "kr": "/mnt/data/02.mongodb_update_fix.py",
        "us": "/mnt/data/02.mongodb_update_fix.py",
        "indices": "/mnt/data/02.mongodb_update_fix.py",
        "currencies": "/mnt/data/02.mongodb_update_fix.py",
    }
    script = script_map.get(target)
    if not script or not os.path.exists(script):
        return jsonify({"status":"error","detail":"script not found"}), 404
    # spawn detached process so it continues in background
    try:
        subprocess.Popen(["python3", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return jsonify({"status":"started", "script": os.path.basename(script)})
    except Exception as e:
        return jsonify({"status":"error","detail":str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
