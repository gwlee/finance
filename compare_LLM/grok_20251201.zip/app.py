# app.py
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from pymongo import MongoClient
from datetime import datetime, timedelta
import subprocess
from config import MONGO_URI, DB_NAME, ADMIN_PASSWORD

app = Flask(__name__)
app.secret_key = "super-secret-key-2025"

client = MongoClient(MONGO_URI)
db = client[DB_NAME]

# 기존 문서에서 그대로 복사한 티커 리스트
TICKER_LISTS = {
    "currencies": ['KRW=X', 'JPYKRW=X', 'EURKRW=X', 'DX-Y.NYB', 'EURUSD=X'],
    "indices": ['^KS11', '^DJI', '^GSPC', '^IXIC', '^N225'],
    "us_stocks": ['AAPL', 'MSFT', 'GOOGL', 'NVDA', 'TSLA', 'AMD'],
    "korean_stocks": [f"{i}.KS" for i in ["005930","000660","373220","005380","000270"]]
    # 실제 운영 시 원본 긴 리스트 사용
}

# 메타데이터 캐시
def refresh_metadata_cache():
    cache = {}
    for doc in db.ticker_metadata.find():
        cache[doc["ticker"]] = {"name": doc.get("name", doc["ticker"]), "type": doc.get("market_type", "unknown")}
    return cache

METADATA_CACHE = refresh_metadata_cache()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/viewer/<category>")
def viewer(category):
    return render_template("viewer.html", category=category)

@app.route("/compare")
def compare():
    return render_template("compare.html")

# 검색 자동완성
@app.route("/api/search")
def search():
    q = request.args.get("q", "").upper()
    results = []
    for t, info in METADATA_CACHE.items():
        if q in t or q in info["name"].upper():
            results.append({"ticker": t, "name": info["name"], "type": info["type"]})
        if len(results) >= 20:
            break
    return jsonify(results[:20])

# 차트 데이터
@app.route("/api/data")
def api_data():
    ticker = request.args.get("ticker")
    collection = request.args.get("collection")
    days = int(request.args.get("days", 365))

    coll = db[collection]
    cutoff = datetime.now() - timedelta(days=days+100)
    cursor = coll.find({"symbol": ticker, "date": {"$gte": cutoff}}).sort("date", 1)

    data = []
    for doc in cursor:
        d = doc["date"]
        if isinstance(d, datetime):
            d = d.strftime("%Y-%m-%d")
        data.append({
            "date": d,
            "open": doc["open"],
            "high": doc["high"],
            "low": doc["low"],
            "close": doc["close"],
            "volume": doc.get("volume", 0)
        })
    return jsonify(data)

# ────────────────── 관리자 ──────────────────
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if request.form["password"] == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect("/admin")
        flash("비밀번호가 틀렸습니다.")
    return render_template("admin/login.html")

@app.route("/admin")
def admin():
    if not session.get("admin"):
        return redirect("/admin/login")
    return render_template("admin/admin.html")

@app.route("/admin/metadata")
def admin_metadata():
    if not session.get("admin"):
        return redirect("/admin/login")
    page = int(request.args.get("page", 1))
    per_page = 50
    total = db.ticker_metadata.count_documents({})
    items = list(db.ticker_metadata.find().skip((page-1)*per_page).limit(per_page))
    return render_template("admin/metadata.html", items=items, page=page,
                           total=total, pages=(total+per_page-1)//per_page)

@app.route("/admin/metadata/save", methods=["POST"])
def save_metadata():
    if not session.get("admin"):
        return jsonify({"error": "unauthorized"}), 401
    data = request.json
    for item in data:
        db.ticker_metadata.update_one(
            {"ticker": item["ticker"]},
            {"$set": {"name": item["name"], "market_type": item["type"], "updated_at": datetime.utcnow()}},
            upsert=True
        )
    global METADATA_CACHE
    METADATA_CACHE = refresh_metadata_cache()
    return jsonify({"status": "ok"})

@app.route("/admin/update/<category>")
def trigger_update(category):
    if not session.get("admin"):
        return "Unauthorized", 401
    if category not in TICKER_LISTS:
        return "Invalid category", 400
    subprocess.Popen(["python", "run_update.py", category])
    return jsonify({"status": "started", "category": category})

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True, port=5000)