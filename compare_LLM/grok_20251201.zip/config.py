MONGO_URI = "mongodb://localhost:27017/"
DB_NAME = "finance_db"
ADMIN_PASSWORD = "admin123"   # 원하면 변경하세요