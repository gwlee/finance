# utils/update_scripts.py
import yfinance as yf
from pymongo import MongoClient
from datetime import datetime, timedelta
from curl_cffi import requests
import pandas as pd
import time

session = requests.Session(impersonate="chrome120")

def update_category(category: str, tickers: list):
    client = MongoClient("mongodb://localhost:27017/")
    db = client["finance_db"]
    coll = db[category]

    for symbol in tickers:
        try:
            # 최신 날짜 확인
            latest = coll.find_one({"symbol": symbol}, sort=[("date", -1)])
            start = "1900-01-01"
            if latest:
                last_date = latest["date"]
                if isinstance(last_date, datetime):
                    last_date = last_date.date()
                if last_date >= datetime.now().date():
                    print(f"[{symbol}] 이미 최신")
                    continue
                start = (last_date + timedelta(days=1)).strftime("%Y-%m-%d")

            ticker = yf.Ticker(symbol, session=session)
            df = ticker.history(start=start)

            if df.empty:
                continue

            records = []
            for date, row in df.iterrows():
                record = {
                    "symbol": symbol,
                    "date": date.to_pydatetime(),
                    "open": float(row["Open"]),
                    "high": float(row["High"]),
                    "low": float(row["Low"]),
                    "close": float(row["Close"]),
                    "volume": int(row["Volume"]) if not pd.isna(row["Volume"]) else 0,
                    "dividends": float(row.get("Dividends", 0)),
                    "stock_splits": float(row.get("Stock Splits", 0)),
                }
                records.append(record)

            if records:
                coll.insert_many(records, ordered=False)
                print(f"[{symbol}] +{len(records)}건 업데이트")
            time.sleep(0.15)
        except Exception as e:
            print(f"[{symbol}] 오류: {e}")

    client.close()