# run_update.py
import sys
from utils.update_scripts import update_category

# 아래 티커 리스트는 실제 코드에 있는 TICKER_LISTS와 동일하게 사용
from app import TICKER_LISTS

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("사용법: python run_update.py [korean_stocks|us_stocks|indices|currencies]")
        sys.exit(1)

    category = sys.argv[1]
    tickers = TICKER_LISTS.get(category, [])
    print(f"{category} 업데이트 시작 ({len(tickers)}개)")
    update_category(category, tickers)
    print(f"{category} 업데이트 완료")