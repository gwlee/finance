let chart, candleSeries;

function initChart() {
    chart = LightweightCharts.createChart(document.getElementById('chart'), {
        width: document.getElementById('chart').clientWidth,
        height: 650,
        layout: { backgroundColor: '#fff', textColor: '#333' },
        grid: { vertLines: { color: '#e0e0e0' }, horzLines: { color: '#e0e0e0' } },
        timeScale: { timeVisible: true, secondsVisible: false }
    });
    candleSeries = chart.addCandlestickSeries();
}

function loadTicker(ticker, collection, maDays = []) {
    fetch(`/api/data?ticker=${ticker}&collection=${collection}&days=1095`)
        .then(r => r.json())
        .then(data => {
            candleSeries.setData(data.map(d => ({
                time: d.date,
                open: d.open,
                high: d.high,
                low: d.low,
                close: d.close
            })));

            // 기존 이동평균선 제거
            chart.removeSeries(chart.series?.filter(s => s !== candleSeries));
            maDays.forEach(days => {
                const ma = calculateMA(data, days);
                const color = days <= 20 ? '#e91e63' : days <= 60 ? '#2196f3' : '#4caf50';
                const line = chart.addLineSeries({ color, lineWidth: 2, title: `${days}일선` });
                line.setData(ma);
            });
        });
}

function calculateMA(data, period) {
    const result = [];
    for (let i = period - 1; i < data.length; i++) {
        let sum = 0;
        for (let j = 0; j < period; j++) sum += data[i - j].close;
        result.push({ time: data[i].date, value: sum / period });
    }
    return result;
}