from common import run_update

if __name__ == "__main__":
    run_update("us_stocks", "finance_db.us_stocks")