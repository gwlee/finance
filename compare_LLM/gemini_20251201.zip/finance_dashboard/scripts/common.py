import os
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from pymongo import MongoClient, BulkWriteError
from concurrent.futures import ThreadPoolExecutor, as_completed
from curl_cffi import requests
import ssl, certifi
import time

# 설정
MONGO_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "finance_db"
MAX_WORKERS = 4
HEADERS = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
}

# 세션 생성
session = requests.Session(impersonate="chrome", headers=HEADERS, verify=False)

def get_db():
    client = MongoClient(MONGO_URI)
    return client[DATABASE_NAME]

def get_latest_date(db, collection_name, symbol):
    pipeline = [
        {"$match": {"symbol": symbol}},
        {"$sort": {"date": -1}},
        {"$limit": 1}
    ]
    result = list(db[collection_name].aggregate(pipeline))
    if result:
        return result[0]['date']
    return None

def fetch_and_insert(symbol, collection_name, market_type):
    db = get_db()
    collection = db[collection_name]
    
    latest_date = get_latest_date(db, collection_name, symbol)
    today = datetime.now().date()
    
    start_date = "1990-01-01"
    if latest_date:
        if isinstance(latest_date, datetime):
            latest_date = latest_date.date()
        start_date = (latest_date + timedelta(days=1)).strftime("%Y-%m-%d")
        if latest_date >= today:
            print(f"[{symbol}] Already up to date.")
            return

    print(f"[{symbol}] Fetching from {start_date}...")
    try:
        ticker = yf.Ticker(symbol, session=session)
        df = ticker.history(start=start_date)
        
        if df.empty:
            print(f"[{symbol}] No new data.")
            return

        df = df.reset_index()
        documents = []
        for _, row in df.iterrows():
            try:
                date_obj = pd.to_datetime(row['Date']).to_pydatetime()
            except: continue
            
            doc = {
                "symbol": symbol,
                "date": date_obj,
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"]),
                "volume": int(row["Volume"]) if not pd.isna(row['Volume']) else 0
            }
            documents.append(doc)
            
        if documents:
            try:
                collection.insert_many(documents, ordered=False)
                print(f"[{symbol}] Inserted {len(documents)} records.")
                
                # 메타데이터 업데이트 (최신 날짜)
                db["finance_db.ticker_metadata"].update_one(
                    {"ticker": symbol}, 
                    {"$set": {"updated_at": datetime.now()}}
                )
            except BulkWriteError:
                pass # 중복 무시
                
    except Exception as e:
        print(f"[{symbol}] Error: {e}")

def run_update(market_type, collection_name):
    print(f"Starting update for {market_type} -> {collection_name}")
    db = get_db()
    
    # 메타데이터에서 활성화된 티커 가져오기
    tickers_cursor = db["finance_db.ticker_metadata"].find(
        {"market_type": market_type, "is_active": True}
    )
    tickers = [t['ticker'] for t in tickers_cursor]
    
    print(f"Found {len(tickers)} tickers to update.")
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(fetch_and_insert, t, collection_name, market_type) for t in tickers]
        for future in as_completed(futures):
            future.result()
            
    print("Update complete.")