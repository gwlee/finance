from common import run_update

if __name__ == "__main__":
    run_update("indices", "finance_db.indices")