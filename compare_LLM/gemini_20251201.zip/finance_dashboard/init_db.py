from pymongo import MongoClient
import yfinance as yf

# 제공해주신 json 파일의 티커 리스트 (일부만 예시로 포함, 나머지는 직접 추가 필요)
# 실제 사용 시 전체 리스트를 여기에 복사해 넣으세요.
TICKER_DATA = {
    "us_stocks": ["AAPL", "MSFT", "TSLA", "NVDA", "AMZN", "GOOGL", "META", "NFLX", "AMD", "INTC"],
    "korean_stocks": ["005930.KS", "000660.KS", "035420.KS", "035720.KS", "005380.KS", "051910.KS"],
    "indices": ["^GSPC", "^DJI", "^IXIC", "^KS11", "^KQ11"],
    "currencies": ["KRW=X", "EURUSD=X", "JPY=X"]
}

DEFAULT_NAMES = {
    "AAPL": "Apple", "MSFT": "Microsoft", "TSLA": "Tesla", "NVDA": "NVIDIA",
    "005930.KS": "삼성전자", "000660.KS": "SK하이닉스", "035420.KS": "NAVER",
    "^GSPC": "S&P 500", "^KS11": "KOSPI", "KRW=X": "USD/KRW"
}

def init_db():
    client = MongoClient("mongodb://localhost:27017/")
    db = client["finance_db"]
    coll = db["finance_db.ticker_metadata"]
    
    # 인덱스 생성
    coll.create_index("ticker", unique=True)
    
    print("Initializing Metadata...")
    for m_type, tickers in TICKER_DATA.items():
        for t in tickers:
            existing = coll.find_one({"ticker": t})
            if not existing:
                name = DEFAULT_NAMES.get(t, t)
                doc = {
                    "ticker": t,
                    "market_type": m_type,
                    "name": name,
                    "is_active": True,
                    "updated_at": None
                }
                coll.insert_one(doc)
                print(f"Added: {t} ({m_type})")
    
    print("DB Initialization Complete!")

if __name__ == "__main__":
    init_db()