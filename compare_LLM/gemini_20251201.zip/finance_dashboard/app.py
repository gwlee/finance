from flask import Flask, render_template, request, jsonify, redirect, url_for
from pymongo import MongoClient
import pandas as pd
import json
import subprocess
import os
from datetime import datetime
from bson import ObjectId

app = Flask(__name__)

# DB 설정
MONGO_URI = "mongodb://localhost:27017/"
client = MongoClient(MONGO_URI)
db = client["finance_db"]

# 컬렉션 매핑
COLLECTIONS = {
    "korean_stocks": "finance_db.korean_stocks",
    "us_stocks": "finance_db.us_stocks",
    "indices": "finance_db.indices",
    "currencies": "finance_db.currencies"
}

MARKET_TYPES = {
    "korean_stocks": "한국 주식",
    "us_stocks": "미국 주식",
    "indices": "지수",
    "currencies": "환율"
}

@app.route('/')
def index():
    return redirect(url_for('view_market', market_type='us_stocks'))

@app.route('/view/<market_type>')
def view_market(market_type):
    if market_type not in COLLECTIONS:
        return redirect(url_for('index'))
    return render_template('index.html', market_type=market_type, market_name=MARKET_TYPES[market_type])

@app.route('/compare')
def compare():
    return render_template('compare.html')

@app.route('/admin')
def admin():
    return render_template('admin.html', market_types=MARKET_TYPES)

# --- API ---

@app.route('/api/search')
def api_search():
    query = request.args.get('q', '').upper()
    market_type = request.args.get('type', 'all')
    
    filter_query = {
        "$or": [
            {"ticker": {"$regex": query, "$options": "i"}},
            {"name": {"$regex": query, "$options": "i"}}
        ],
        "is_active": True
    }
    
    if market_type != 'all':
        filter_query["market_type"] = market_type

    results = list(db["finance_db.ticker_metadata"].find(filter_query, {"_id": 0}).limit(20))
    return jsonify(results)

@app.route('/api/chart_data')
def api_chart_data():
    symbol = request.args.get('symbol')
    market_type = request.args.get('type')
    
    if not symbol or not market_type:
        return jsonify({"error": "Missing params"}), 400
        
    coll_name = COLLECTIONS.get(market_type)
    if not coll_name:
        return jsonify({"error": "Invalid type"}), 400

    # 데이터 조회
    pipeline = [
        {"$match": {"symbol": symbol}},
        {"$sort": {"date": 1}}
    ]
    data = list(db[coll_name].aggregate(pipeline))
    
    if not data:
        return jsonify({"error": "No data"}), 404
        
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'])
    
    result = {
        "dates": df['date'].dt.strftime('%Y-%m-%d').tolist(),
        "open": df['open'].tolist(),
        "high": df['high'].tolist(),
        "low": df['low'].tolist(),
        "close": df['close'].tolist(),
        "volume": df['volume'].tolist(),
        "ma": {}
    }
    
    # 이동평균선 계산 로직
    ma_windows = []
    if market_type == 'korean_stocks':
        ma_windows = [5, 20, 60, 120]
    elif market_type == 'us_stocks':
        ma_windows = [5, 10, 20, 50, 200]
    elif market_type == 'indices':
        ma_windows = [5, 10, 20, 50, 60, 120, 200] # 옵션 모두 제공, 프론트에서 토글
        
    for window in ma_windows:
        if len(df) >= window:
            result['ma'][f'MA{window}'] = df['close'].rolling(window=window).mean().where(pd.notnull(df['close'].rolling(window=window).mean()), None).tolist()

    return jsonify(result)

@app.route('/api/compare_data', methods=['POST'])
def api_compare_data():
    req = request.json
    tickers = req.get('tickers', [])
    
    response_data = []
    
    for item in tickers:
        symbol = item['ticker']
        # 심볼로 market_type 찾기
        meta = db["finance_db.ticker_metadata"].find_one({"ticker": symbol})
        if not meta: 
            continue
            
        market_type = meta['market_type']
        coll_name = COLLECTIONS.get(market_type)
        
        data = list(db[coll_name].find({"symbol": symbol}).sort("date", 1))
        if not data:
            continue
            
        df = pd.DataFrame(data)
        
        # 정규화 (Normalization) 로직: 첫 가격 기준 등락률
        if not df.empty:
            start_price = df.iloc[0]['close']
            df['normalized'] = ((df['close'] - start_price) / start_price) * 100
            
            response_data.append({
                "ticker": symbol,
                "name": meta.get('name', symbol),
                "dates": df['date'].dt.strftime('%Y-%m-%d').tolist(),
                "close": df['close'].tolist(),
                "normalized": df['normalized'].tolist()
            })
            
    return jsonify(response_data)

# --- Admin API ---

@app.route('/api/metadata', methods=['GET', 'PUT'])
def api_metadata():
    if request.method == 'GET':
        page = int(request.args.get('page', 1))
        per_page = 20
        market_type = request.args.get('market_type')
        query = request.args.get('q', '')
        
        filter_q = {}
        if market_type: filter_q['market_type'] = market_type
        if query: filter_q['$or'] = [{"ticker": {"$regex": query, "$options": "i"}}, {"name": {"$regex": query, "$options": "i"}}]
        
        total = db["finance_db.ticker_metadata"].count_documents(filter_q)
        cursor = db["finance_db.ticker_metadata"].find(filter_q).skip((page-1)*per_page).limit(per_page)
        
        items = []
        for doc in cursor:
            doc['_id'] = str(doc['_id'])
            items.append(doc)
            
        return jsonify({"items": items, "total": total, "page": page, "pages": (total // per_page) + 1})

    if request.method == 'PUT':
        data = request.json
        oid = data.get('_id')
        update_data = {
            "name": data.get('name'),
            "is_active": data.get('is_active')
        }
        db["finance_db.ticker_metadata"].update_one({"_id": ObjectId(oid)}, {"$set": update_data})
        return jsonify({"success": True})

@app.route('/api/trigger_update', methods=['POST'])
def trigger_update():
    script_type = request.json.get('type')
    script_map = {
        "korean_stocks": "update_kr.py",
        "us_stocks": "update_us.py",
        "indices": "update_indices.py",
        "currencies": "update_currencies.py"
    }
    
    script_name = script_map.get(script_type)
    if not script_name:
        return jsonify({"error": "Invalid type"}), 400
        
    # 백그라운드 실행 (Windows/Linux 호환)
    script_path = os.path.join("scripts", script_name)
    subprocess.Popen(["python", script_path], shell=True)
    
    return jsonify({"message": f"Started {script_name}"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)