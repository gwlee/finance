import os

# 프로젝트 구조 정의
structure = {
    "finance_dashboard": {
        "app.py": "",
        "init_db.py": "",
        "requirements.txt": "flask\npymongo\npandas\nyfinance\nplotly\ncurl_cffi\ncertifi\nnumpy",
        "scripts": {
            "__init__.py": "",
            "common.py": "",
            "update_kr.py": "",
            "update_us.py": "",
            "update_indices.py": "",
            "update_currencies.py": ""
        },
        "static": {
            "css": {
                "style.css": ""
            },
            "js": {
                "main.js": ""
            }
        },
        "templates": {
            "layout.html": "",
            "index.html": "",
            "compare.html": "",
            "admin.html": ""
        }
    }
}

# ---------------------------------------------------------
# 파일 내용 정의
# ---------------------------------------------------------

# 1. app.py
contents_app_py = r'''
from flask import Flask, render_template, request, jsonify, redirect, url_for
from pymongo import MongoClient
import pandas as pd
import json
import subprocess
import os
from datetime import datetime
from bson import ObjectId

app = Flask(__name__)

# DB 설정
MONGO_URI = "mongodb://localhost:27017/"
client = MongoClient(MONGO_URI)
db = client["finance_db"]

# 컬렉션 매핑
COLLECTIONS = {
    "korean_stocks": "finance_db.korean_stocks",
    "us_stocks": "finance_db.us_stocks",
    "indices": "finance_db.indices",
    "currencies": "finance_db.currencies"
}

MARKET_TYPES = {
    "korean_stocks": "한국 주식",
    "us_stocks": "미국 주식",
    "indices": "지수",
    "currencies": "환율"
}

@app.route('/')
def index():
    return redirect(url_for('view_market', market_type='us_stocks'))

@app.route('/view/<market_type>')
def view_market(market_type):
    if market_type not in COLLECTIONS:
        return redirect(url_for('index'))
    return render_template('index.html', market_type=market_type, market_name=MARKET_TYPES[market_type])

@app.route('/compare')
def compare():
    return render_template('compare.html')

@app.route('/admin')
def admin():
    return render_template('admin.html', market_types=MARKET_TYPES)

# --- API ---

@app.route('/api/search')
def api_search():
    query = request.args.get('q', '').upper()
    market_type = request.args.get('type', 'all')
    
    filter_query = {
        "$or": [
            {"ticker": {"$regex": query, "$options": "i"}},
            {"name": {"$regex": query, "$options": "i"}}
        ],
        "is_active": True
    }
    
    if market_type != 'all':
        filter_query["market_type"] = market_type

    results = list(db["finance_db.ticker_metadata"].find(filter_query, {"_id": 0}).limit(20))
    return jsonify(results)

@app.route('/api/chart_data')
def api_chart_data():
    symbol = request.args.get('symbol')
    market_type = request.args.get('type')
    
    if not symbol or not market_type:
        return jsonify({"error": "Missing params"}), 400
        
    coll_name = COLLECTIONS.get(market_type)
    if not coll_name:
        return jsonify({"error": "Invalid type"}), 400

    # 데이터 조회
    pipeline = [
        {"$match": {"symbol": symbol}},
        {"$sort": {"date": 1}}
    ]
    data = list(db[coll_name].aggregate(pipeline))
    
    if not data:
        return jsonify({"error": "No data"}), 404
        
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'])
    
    result = {
        "dates": df['date'].dt.strftime('%Y-%m-%d').tolist(),
        "open": df['open'].tolist(),
        "high": df['high'].tolist(),
        "low": df['low'].tolist(),
        "close": df['close'].tolist(),
        "volume": df['volume'].tolist(),
        "ma": {}
    }
    
    # 이동평균선 계산 로직
    ma_windows = []
    if market_type == 'korean_stocks':
        ma_windows = [5, 20, 60, 120]
    elif market_type == 'us_stocks':
        ma_windows = [5, 10, 20, 50, 200]
    elif market_type == 'indices':
        ma_windows = [5, 10, 20, 50, 60, 120, 200] # 옵션 모두 제공, 프론트에서 토글
        
    for window in ma_windows:
        if len(df) >= window:
            result['ma'][f'MA{window}'] = df['close'].rolling(window=window).mean().where(pd.notnull(df['close'].rolling(window=window).mean()), None).tolist()

    return jsonify(result)

@app.route('/api/compare_data', methods=['POST'])
def api_compare_data():
    req = request.json
    tickers = req.get('tickers', [])
    
    response_data = []
    
    for item in tickers:
        symbol = item['ticker']
        # 심볼로 market_type 찾기
        meta = db["finance_db.ticker_metadata"].find_one({"ticker": symbol})
        if not meta: 
            continue
            
        market_type = meta['market_type']
        coll_name = COLLECTIONS.get(market_type)
        
        data = list(db[coll_name].find({"symbol": symbol}).sort("date", 1))
        if not data:
            continue
            
        df = pd.DataFrame(data)
        
        # 정규화 (Normalization) 로직: 첫 가격 기준 등락률
        if not df.empty:
            start_price = df.iloc[0]['close']
            df['normalized'] = ((df['close'] - start_price) / start_price) * 100
            
            response_data.append({
                "ticker": symbol,
                "name": meta.get('name', symbol),
                "dates": df['date'].dt.strftime('%Y-%m-%d').tolist(),
                "close": df['close'].tolist(),
                "normalized": df['normalized'].tolist()
            })
            
    return jsonify(response_data)

# --- Admin API ---

@app.route('/api/metadata', methods=['GET', 'PUT'])
def api_metadata():
    if request.method == 'GET':
        page = int(request.args.get('page', 1))
        per_page = 20
        market_type = request.args.get('market_type')
        query = request.args.get('q', '')
        
        filter_q = {}
        if market_type: filter_q['market_type'] = market_type
        if query: filter_q['$or'] = [{"ticker": {"$regex": query, "$options": "i"}}, {"name": {"$regex": query, "$options": "i"}}]
        
        total = db["finance_db.ticker_metadata"].count_documents(filter_q)
        cursor = db["finance_db.ticker_metadata"].find(filter_q).skip((page-1)*per_page).limit(per_page)
        
        items = []
        for doc in cursor:
            doc['_id'] = str(doc['_id'])
            items.append(doc)
            
        return jsonify({"items": items, "total": total, "page": page, "pages": (total // per_page) + 1})

    if request.method == 'PUT':
        data = request.json
        oid = data.get('_id')
        update_data = {
            "name": data.get('name'),
            "is_active": data.get('is_active')
        }
        db["finance_db.ticker_metadata"].update_one({"_id": ObjectId(oid)}, {"$set": update_data})
        return jsonify({"success": True})

@app.route('/api/trigger_update', methods=['POST'])
def trigger_update():
    script_type = request.json.get('type')
    script_map = {
        "korean_stocks": "update_kr.py",
        "us_stocks": "update_us.py",
        "indices": "update_indices.py",
        "currencies": "update_currencies.py"
    }
    
    script_name = script_map.get(script_type)
    if not script_name:
        return jsonify({"error": "Invalid type"}), 400
        
    # 백그라운드 실행 (Windows/Linux 호환)
    script_path = os.path.join("scripts", script_name)
    subprocess.Popen(["python", script_path], shell=True)
    
    return jsonify({"message": f"Started {script_name}"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
'''

# 2. scripts/common.py (업데이트 로직 공통 모듈)
contents_common_py = r'''
import os
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from pymongo import MongoClient, BulkWriteError
from concurrent.futures import ThreadPoolExecutor, as_completed
from curl_cffi import requests
import ssl, certifi
import time

# 설정
MONGO_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "finance_db"
MAX_WORKERS = 4
HEADERS = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'
}

# 세션 생성
session = requests.Session(impersonate="chrome", headers=HEADERS, verify=False)

def get_db():
    client = MongoClient(MONGO_URI)
    return client[DATABASE_NAME]

def get_latest_date(db, collection_name, symbol):
    pipeline = [
        {"$match": {"symbol": symbol}},
        {"$sort": {"date": -1}},
        {"$limit": 1}
    ]
    result = list(db[collection_name].aggregate(pipeline))
    if result:
        return result[0]['date']
    return None

def fetch_and_insert(symbol, collection_name, market_type):
    db = get_db()
    collection = db[collection_name]
    
    latest_date = get_latest_date(db, collection_name, symbol)
    today = datetime.now().date()
    
    start_date = "1990-01-01"
    if latest_date:
        if isinstance(latest_date, datetime):
            latest_date = latest_date.date()
        start_date = (latest_date + timedelta(days=1)).strftime("%Y-%m-%d")
        if latest_date >= today:
            print(f"[{symbol}] Already up to date.")
            return

    print(f"[{symbol}] Fetching from {start_date}...")
    try:
        ticker = yf.Ticker(symbol, session=session)
        df = ticker.history(start=start_date)
        
        if df.empty:
            print(f"[{symbol}] No new data.")
            return

        df = df.reset_index()
        documents = []
        for _, row in df.iterrows():
            try:
                date_obj = pd.to_datetime(row['Date']).to_pydatetime()
            except: continue
            
            doc = {
                "symbol": symbol,
                "date": date_obj,
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"]),
                "volume": int(row["Volume"]) if not pd.isna(row['Volume']) else 0
            }
            documents.append(doc)
            
        if documents:
            try:
                collection.insert_many(documents, ordered=False)
                print(f"[{symbol}] Inserted {len(documents)} records.")
                
                # 메타데이터 업데이트 (최신 날짜)
                db["finance_db.ticker_metadata"].update_one(
                    {"ticker": symbol}, 
                    {"$set": {"updated_at": datetime.now()}}
                )
            except BulkWriteError:
                pass # 중복 무시
                
    except Exception as e:
        print(f"[{symbol}] Error: {e}")

def run_update(market_type, collection_name):
    print(f"Starting update for {market_type} -> {collection_name}")
    db = get_db()
    
    # 메타데이터에서 활성화된 티커 가져오기
    tickers_cursor = db["finance_db.ticker_metadata"].find(
        {"market_type": market_type, "is_active": True}
    )
    tickers = [t['ticker'] for t in tickers_cursor]
    
    print(f"Found {len(tickers)} tickers to update.")
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(fetch_and_insert, t, collection_name, market_type) for t in tickers]
        for future in as_completed(futures):
            future.result()
            
    print("Update complete.")
'''

# 3. 개별 업데이트 스크립트들
script_template = r'''
from common import run_update

if __name__ == "__main__":
    run_update("{market_type}", "finance_db.{coll_name}")
'''

# 4. Templates

# layout.html
contents_layout = r'''
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/static/css/style.css">
    <script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="d-flex" id="wrapper">
        <div class="bg-dark text-white p-3" id="sidebar-wrapper" style="width: 250px; min-height: 100vh;">
            <div class="sidebar-heading fs-4 fw-bold mb-4">Finance Dash</div>
            <div class="list-group list-group-flush">
                <a href="/view/us_stocks" class="list-group-item list-group-item-action list-group-item-dark">🇺🇸 미국 주식</a>
                <a href="/view/korean_stocks" class="list-group-item list-group-item-action list-group-item-dark">🇰🇷 한국 주식</a>
                <a href="/view/indices" class="list-group-item list-group-item-action list-group-item-dark">📊 지수</a>
                <a href="/view/currencies" class="list-group-item list-group-item-action list-group-item-dark">💱 환율</a>
                <hr>
                <a href="/compare" class="list-group-item list-group-item-action list-group-item-dark">⚖️ 비교 분석</a>
                <a href="/admin" class="list-group-item list-group-item-action list-group-item-dark">⚙️ 관리자</a>
            </div>
        </div>
        
        <div id="page-content-wrapper" class="w-100 p-4">
            {% block content %}{% endblock %}
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/static/js/main.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
'''

# index.html
contents_index = r'''
{% extends "layout.html" %}
{% block content %}
<div class="container-fluid">
    <h2 class="mb-4">{{ market_name }} 차트</h2>
    
    <div class="row mb-3">
        <div class="col-md-6 position-relative">
            <input type="text" id="symbol-search" class="form-control" placeholder="종목 코드 또는 이름 검색..." autocomplete="off">
            <div id="search-results" class="list-group position-absolute w-100" style="z-index: 1000; display:none;"></div>
        </div>
    </div>

    <div id="chart-container" style="height: 600px; border: 1px solid #ddd; border-radius: 5px;" class="d-flex align-items-center justify-content-center bg-light">
        <span class="text-muted">검색하여 종목을 선택하세요.</span>
    </div>
</div>

<script>
    const currentMarketType = "{{ market_type }}";
    
    $(document).ready(function() {
        $('#symbol-search').on('input', function() {
            const q = $(this).val();
            if(q.length < 1) { $('#search-results').hide(); return; }
            
            $.get(`/api/search?q=${q}&type=${currentMarketType}`, function(data) {
                let html = '';
                data.forEach(item => {
                    html += `<a href="#" class="list-group-item list-group-item-action" 
                                onclick="loadChart('${item.ticker}', '${item.name}'); return false;">
                                <strong>${item.name}</strong> <small class="text-muted">(${item.ticker})</small>
                             </a>`;
                });
                $('#search-results').html(html).show();
            });
        });
    });

    function loadChart(symbol, name) {
        $('#search-results').hide();
        $('#symbol-search').val(`${name} (${symbol})`);
        
        // 차트 로딩 표시
        $('#chart-container').html('<div class="spinner-border text-primary" role="status"></div>');

        $.get(`/api/chart_data?symbol=${symbol}&type=${currentMarketType}`, function(data) {
            $('#chart-container').html(''); // 스피너 제거
            
            // 캔들스틱 데이터
            var trace1 = {
                x: data.dates,
                close: data.close,
                high: data.high,
                low: data.low,
                open: data.open,
                
                decreasing: {line: {color: 'blue'}}, // 한국식 (파랑 하락)
                increasing: {line: {color: 'red'}},  // 한국식 (빨강 상승)
                
                line: {color: 'rgba(31,119,180,1)'},
                type: 'candlestick', 
                xaxis: 'x', 
                yaxis: 'y',
                name: symbol
            };
            
            var traces = [trace1];
            
            // 이동평균선 추가
            const colors = ['#FF5733', '#33FF57', '#3357FF', '#F333FF', '#33FFF6'];
            let colorIdx = 0;
            for (const [maName, maData] of Object.entries(data.ma)) {
                traces.push({
                    x: data.dates,
                    y: maData,
                    type: 'scatter',
                    mode: 'lines',
                    name: maName,
                    line: { width: 1, color: colors[colorIdx++ % colors.length] }
                });
            }

            var layout = {
                dragmode: 'zoom', 
                showlegend: true, 
                xaxis: {
                    rangeslider: { visible: false },
                    type: 'date',
                    rangebreaks: [{ bounds: ["sat", "mon"] }] // 주말 스킵
                }, 
                yaxis: {
                    autorange: true, 
                    type: 'linear'
                },
                title: `${name} (${symbol})`
            };

            Plotly.newPlot('chart-container', traces, layout);
        }).fail(function() {
            $('#chart-container').html('<span class="text-danger">데이터를 불러올 수 없습니다.</span>');
        });
    }
</script>
{% endblock %}
'''

# compare.html
contents_compare = r'''
{% extends "layout.html" %}
{% block content %}
<div class="container-fluid">
    <h2 class="mb-4">통합 비교 분석</h2>
    
    <div class="row mb-3">
        <div class="col-md-5 position-relative">
            <input type="text" id="comp-search" class="form-control" placeholder="비교할 종목 추가 (전체 검색)...">
            <div id="comp-results" class="list-group position-absolute w-100" style="z-index: 1000; display:none;"></div>
        </div>
        <div class="col-md-7">
            <div id="selected-badges" class="d-flex flex-wrap gap-2 align-items-center h-100">
                </div>
        </div>
    </div>
    
    <div class="form-check mb-2">
        <input class="form-check-input" type="checkbox" id="normalize-check" checked>
        <label class="form-check-label" for="normalize-check">
            정규화 (%) 비교 (해제 시 2개 종목 Dual-Axis)
        </label>
    </div>

    <div id="compare-chart" style="height: 600px; border: 1px solid #ddd;" class="bg-light"></div>
</div>

<script>
    let selectedTickers = [];

    $(document).ready(function() {
        $('#comp-search').on('input', function() {
            const q = $(this).val();
            if(q.length < 1) { $('#comp-results').hide(); return; }
            
            $.get(`/api/search?q=${q}&type=all`, function(data) {
                let html = '';
                data.forEach(item => {
                    html += `<a href="#" class="list-group-item list-group-item-action" 
                                onclick="addTicker('${item.ticker}', '${item.name}'); return false;">
                                ${item.name} (${item.ticker}) <span class="badge bg-secondary">${item.market_type}</span>
                             </a>`;
                });
                $('#comp-results').html(html).show();
            });
        });
    });

    function addTicker(ticker, name) {
        if(selectedTickers.find(t => t.ticker === ticker)) return;
        selectedTickers.push({ticker, name});
        $('#comp-results').hide();
        $('#comp-search').val('');
        renderBadges();
        updateChart();
    }

    function removeTicker(ticker) {
        selectedTickers = selectedTickers.filter(t => t.ticker !== ticker);
        renderBadges();
        updateChart();
    }

    function renderBadges() {
        const html = selectedTickers.map(t => 
            `<span class="badge bg-primary p-2">
                ${t.name} <button type="button" class="btn-close btn-close-white ms-2" style="font-size:0.5em" onclick="removeTicker('${t.ticker}')"></button>
             </span>`
        ).join('');
        $('#selected-badges').html(html);
    }

    function updateChart() {
        if(selectedTickers.length === 0) {
            Plotly.purge('compare-chart');
            return;
        }

        const normalize = $('#normalize-check').is(':checked');

        $.ajax({
            url: '/api/compare_data',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ tickers: selectedTickers }),
            success: function(data) {
                let traces = [];
                let layout = {
                    title: '비교 차트',
                    xaxis: { type: 'date', rangebreaks: [{ bounds: ["sat", "mon"] }] },
                    yaxis: { title: 'Value' },
                    showlegend: true
                };

                // 로직: 정규화 체크가 되어있거나 종목이 3개 이상이면 무조건 정규화 차트
                if (normalize || data.length > 2) {
                    layout.yaxis.title = '변동률 (%)';
                    data.forEach(d => {
                        traces.push({
                            x: d.dates,
                            y: d.normalized,
                            mode: 'lines',
                            name: d.name
                        });
                    });
                } else if (data.length === 2) {
                    // Dual Axis
                    traces.push({
                        x: data[0].dates,
                        y: data[0].close,
                        name: data[0].name,
                        type: 'scatter'
                    });
                    traces.push({
                        x: data[1].dates,
                        y: data[1].close,
                        name: data[1].name,
                        type: 'scatter',
                        yaxis: 'y2'
                    });
                    
                    layout.yaxis.title = data[0].name;
                    layout.yaxis2 = {
                        title: data[1].name,
                        overlaying: 'y',
                        side: 'right'
                    };
                } else {
                    // 1개일 때
                    traces.push({
                        x: data[0].dates,
                        y: data[0].close,
                        name: data[0].name,
                        type: 'scatter'
                    });
                }

                Plotly.newPlot('compare-chart', traces, layout);
            }
        });
    }
    
    $('#normalize-check').change(updateChart);
</script>
{% endblock %}
'''

# admin.html
contents_admin = r'''
{% extends "layout.html" %}
{% block content %}
<div class="container-fluid">
    <h2 class="mb-4">⚙️ 관리자 페이지</h2>

    <div class="card mb-4">
        <div class="card-header bg-warning">데이터 업데이트 (Background Tasks)</div>
        <div class="card-body">
            <div class="d-flex gap-3">
                {% for key, val in market_types.items() %}
                <button class="btn btn-outline-dark" onclick="triggerUpdate('{{ key }}')">
                    🔄 {{ val }} 업데이트 실행
                </button>
                {% endfor %}
            </div>
            <div id="update-msg" class="mt-2 text-info"></div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs" id="adminTabs">
                {% for key, val in market_types.items() %}
                <li class="nav-item">
                    <a class="nav-link {% if loop.first %}active{% endif %}" href="#" onclick="loadMetadata('{{ key }}', 1); return false;">{{ val }}</a>
                </li>
                {% endfor %}
            </ul>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <input type="text" id="meta-search" class="form-control" placeholder="티커 검색...">
                </div>
                <div class="col-md-2">
                    <button class="btn btn-primary" onclick="searchMeta()">검색</button>
                </div>
            </div>
            
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Ticker</th>
                        <th>Name</th>
                        <th>Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="meta-tbody"></tbody>
            </table>
            
            <nav>
                <ul class="pagination" id="meta-pagination"></ul>
            </nav>
        </div>
    </div>
</div>

<script>
    let currentTab = 'us_stocks';
    let currentPage = 1;

    $(document).ready(function() {
        loadMetadata('us_stocks', 1);
        
        $('#adminTabs a').click(function() {
            $('#adminTabs a').removeClass('active');
            $(this).addClass('active');
            // 텍스트로 키 유추하는 대신 onclick에서 직접 전달받음
        });
    });

    function triggerUpdate(type) {
        if(!confirm('백그라운드에서 업데이트를 시작하시겠습니까?')) return;
        
        $.ajax({
            url: '/api/trigger_update',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ type: type }),
            success: function(res) {
                $('#update-msg').text(res.message);
                setTimeout(() => $('#update-msg').text(''), 5000);
            }
        });
    }

    function loadMetadata(type, page) {
        currentTab = type;
        currentPage = page;
        const q = $('#meta-search').val();
        
        $.get(`/api/metadata?market_type=${type}&page=${page}&q=${q}`, function(res) {
            let html = '';
            res.items.forEach(item => {
                html += `
                <tr>
                    <td>${item.ticker}</td>
                    <td><input type="text" class="form-control form-control-sm" id="name-${item._id}" value="${item.name || ''}"></td>
                    <td>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="active-${item._id}" ${item.is_active ? 'checked' : ''}>
                        </div>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-success" onclick="saveMeta('${item._id}')">저장</button>
                    </td>
                </tr>`;
            });
            $('#meta-tbody').html(html);
            
            // 페이지네이션
            let pageHtml = '';
            for(let i=1; i<=res.pages; i++) {
                if(i > page - 5 && i < page + 5) {
                    pageHtml += `<li class="page-item ${i===page?'active':''}"><a class="page-link" href="#" onclick="loadMetadata('${type}', ${i}); return false;">${i}</a></li>`;
                }
            }
            $('#meta-pagination').html(pageHtml);
        });
    }
    
    function searchMeta() {
        loadMetadata(currentTab, 1);
    }

    function saveMeta(id) {
        const name = $(`#name-${id}`).val();
        const isActive = $(`#active-${id}`).is(':checked');
        
        $.ajax({
            url: '/api/metadata',
            type: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({ _id: id, name: name, is_active: isActive }),
            success: function() {
                alert('저장되었습니다.');
            }
        });
    }
</script>
{% endblock %}
'''

# 5. init_db.py (초기 데이터 셋업 - 제공된 json의 ticker list 일부 사용)
contents_init_db = r'''
from pymongo import MongoClient
import yfinance as yf

# 제공해주신 json 파일의 티커 리스트 (일부만 예시로 포함, 나머지는 직접 추가 필요)
# 실제 사용 시 전체 리스트를 여기에 복사해 넣으세요.
TICKER_DATA = {
    "us_stocks": ["AAPL", "MSFT", "TSLA", "NVDA", "AMZN", "GOOGL", "META", "NFLX", "AMD", "INTC"],
    "korean_stocks": ["005930.KS", "000660.KS", "035420.KS", "035720.KS", "005380.KS", "051910.KS"],
    "indices": ["^GSPC", "^DJI", "^IXIC", "^KS11", "^KQ11"],
    "currencies": ["KRW=X", "EURUSD=X", "JPY=X"]
}

DEFAULT_NAMES = {
    "AAPL": "Apple", "MSFT": "Microsoft", "TSLA": "Tesla", "NVDA": "NVIDIA",
    "005930.KS": "삼성전자", "000660.KS": "SK하이닉스", "035420.KS": "NAVER",
    "^GSPC": "S&P 500", "^KS11": "KOSPI", "KRW=X": "USD/KRW"
}

def init_db():
    client = MongoClient("mongodb://localhost:27017/")
    db = client["finance_db"]
    coll = db["finance_db.ticker_metadata"]
    
    # 인덱스 생성
    coll.create_index("ticker", unique=True)
    
    print("Initializing Metadata...")
    for m_type, tickers in TICKER_DATA.items():
        for t in tickers:
            existing = coll.find_one({"ticker": t})
            if not existing:
                name = DEFAULT_NAMES.get(t, t)
                doc = {
                    "ticker": t,
                    "market_type": m_type,
                    "name": name,
                    "is_active": True,
                    "updated_at": None
                }
                coll.insert_one(doc)
                print(f"Added: {t} ({m_type})")
    
    print("DB Initialization Complete!")

if __name__ == "__main__":
    init_db()
'''

# ---------------------------------------------------------
# 파일 생성 실행
# ---------------------------------------------------------
for path, content in [
    ("finance_dashboard/app.py", contents_app_py),
    ("finance_dashboard/requirements.txt", structure["finance_dashboard"]["requirements.txt"]),
    ("finance_dashboard/init_db.py", contents_init_db),
    ("finance_dashboard/scripts/__init__.py", ""),
    ("finance_dashboard/scripts/common.py", contents_common_py),
    ("finance_dashboard/scripts/update_kr.py", script_template.format(market_type="korean_stocks", coll_name="korean_stocks")),
    ("finance_dashboard/scripts/update_us.py", script_template.format(market_type="us_stocks", coll_name="us_stocks")),
    ("finance_dashboard/scripts/update_indices.py", script_template.format(market_type="indices", coll_name="indices")),
    ("finance_dashboard/scripts/update_currencies.py", script_template.format(market_type="currencies", coll_name="currencies")),
    ("finance_dashboard/templates/layout.html", contents_layout),
    ("finance_dashboard/templates/index.html", contents_index),
    ("finance_dashboard/templates/compare.html", contents_compare),
    ("finance_dashboard/templates/admin.html", contents_admin),
    ("finance_dashboard/static/js/main.js", "// Main JS placeholder"),
    ("finance_dashboard/static/css/style.css", "body { background-color: #f8f9fa; }")
]:
    # 디렉토리 생성
    dir_name = os.path.dirname(path)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
    
    # 파일 쓰기
    with open(path, "w", encoding="utf-8") as f:
        f.write(content.strip())

print("✅ 프로젝트 생성 완료! 'finance_dashboard' 폴더가 생성되었습니다.")
print("👉 실행 방법:")
print("1. cd finance_dashboard")
print("2. pip install -r requirements.txt")
print("3. python init_db.py (초기 메타데이터 생성)")
print("4. python app.py (웹 서버 실행)")
