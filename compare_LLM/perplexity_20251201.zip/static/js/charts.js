// 공통 차트 로드 (페이지별 loadChart 함수에서 호출)
function initZoom() {
    // Plotly 줌/팬 이벤트 (휴장일 스킵은 백엔드에서 처리)
    document.getElementById('chart').on('plotly_relayout', function(event) {
        // 확대/축소 시 재로드 로직
    });
}

// 비교 차트 예시 (compare.html용)
function loadCompare() {
    const symbols = document.getElementById('compare-symbols').value.split(',');
    const types = document.getElementById('compare-types').value.split(',');
    fetch(`/api/compare_chart?symbols=${symbols.join(',')}&types=${types.join(',')}`)
        .then(res => res.json())
        .then(data => {
            if (data.chart) {
                Plotly.newPlot('compare-chart', JSON.parse(data.chart));
            }
        });
}
