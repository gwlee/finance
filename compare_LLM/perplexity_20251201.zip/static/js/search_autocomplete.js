document.addEventListener('DOMContentLoaded', function() {
    const input = document.getElementById('search-input');
    const list = document.getElementById('autocomplete-list');
    
    input.addEventListener('input', function() {
        const query = this.value;
        if (query.length < 2) {
            list.innerHTML = '';
            return;
        }
        fetch(`/api/search/all?q=${encodeURIComponent(query)}`)
            .then(res => res.json())
            .then(results => {
                list.innerHTML = results.map(r => `<li onclick="selectTicker('${r.ticker}', '${r.name}')">${r.ticker} - ${r.name}</li>`).join('');
            });
    });
    
    function selectTicker(ticker, name) {
        document.getElementById('search-input').value = `${ticker} (${name})`;
        list.innerHTML = '';
        // 차트 로드 트리거 (페이지별)
        if (window.loadChart) loadChart('1M', ticker);
    }
});
