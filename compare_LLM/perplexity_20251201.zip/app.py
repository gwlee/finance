from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from pymongo import MongoClient
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.offline import plot
from datetime import datetime, timedelta
import json
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 세션용

# MongoDB 연결
client = MongoClient('mongodb://localhost:27017/')
db = client['finance_db']

# Ticker 메타데이터 컬렉션
ticker_metadata = db['ticker_metadata']

# 데이터 컬렉션
collections = {
    'korean_stocks': db['korean_stocks'],
    'us_stocks': db['us_stocks'],
    'indices': db['indices'],
    'currencies': db['currencies']
}

def get_ticker_data(collection, symbol, period='1M'):
    """기간별 OHLC 데이터 조회 (휴장일 제외)"""
    end_date = datetime.now()
    if period == '1W': start_date = end_date - timedelta(weeks=1)
    elif period == '1M': start_date = end_date - timedelta(days=30)
    elif period == '3M': start_date = end_date - timedelta(days=90)
    elif period == '6M': start_date = end_date - timedelta(days=180)
    elif period == '1Y': start_date = end_date - timedelta(days=365)
    elif period == '3Y': start_date = end_date - timedelta(days=3*365)
    elif period == '5Y': start_date = end_date - timedelta(days=5*365)
    elif period == '10Y': start_date = end_date - timedelta(days=10*365)
    else: start_date = end_date - timedelta(days=365*20)  # 최대

    data = list(collection.find({'symbol': symbol, 'date': {'$gte': start_date}}).sort('date', 1))
    if not data:
        return None
    df = pd.DataFrame(data)
    df['date'] = pd.to_datetime(df['date'])
    df = df.dropna(subset=['open', 'high', 'low', 'close'])  # 휴장일 제외
    return df

def calculate_ma(df, periods):
    """이동평균선 계산"""
    for p in periods:
        df[f'MA_{p}'] = df['close'].rolling(window=p).mean()
    return df

def create_candlestick_chart(df, symbol, ma_periods=None):
    """Plotly 캔들스틱 차트 생성"""
    fig = go.Figure()
    
    # 캔들스틱
    fig.add_trace(go.Candlestick(
        x=df['date'],
        open=df['open'], high=df['high'], low=df['low'], close=df['close'],
        name=symbol
    ))
    
    # 이동평균선 (카테고리별)
    if ma_periods:
        df = calculate_ma(df, ma_periods)
        for p in ma_periods:
            fig.add_trace(go.Scatter(x=df['date'], y=df[f'MA_{p}'], name=f'MA {p}d', line=dict(width=1)))
    
    fig.update_layout(title=f'{symbol} Chart', xaxis_title='Date', yaxis_title='Price',
                      xaxis_rangeslider_visible=True, height=600)
    return fig.to_json()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/korean_stocks')
def korean_stocks():
    return render_template('korean_stocks.html', collection='korean_stocks', ma_periods=[5, 20, 60, 120])

@app.route('/us_stocks')
def us_stocks():
    return render_template('us_stocks.html', collection='us_stocks', ma_periods=[5, 10, 20, 50, 200])

@app.route('/indices')
def indices():
    return render_template('indices.html', collection='indices', ma_periods=[5, 20, 60, 120])  # 옵션1 기본

@app.route('/currencies')
def currencies():
    return render_template('currencies.html', collection='currencies', ma_periods=None)

@app.route('/compare')
def compare():
    return render_template('compare.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

# API: 검색 자동완성
@app.route('/api/search/<collection_name>')
def search_tickers(collection_name):
    query = request.args.get('q', '').lower()
    if collection_name == 'all':
        tickers = list(ticker_metadata.find({'isactive': True}, {'ticker': 1, 'name': 1}))
    else:
        tickers = list(collections[collection_name].distinct('symbol'))
    results = [{'ticker': t['ticker'], 'name': t.get('name', t['ticker'])} for t in tickers if query in t['ticker'].lower() or query in str(t.get('name', '')).lower()]
    return jsonify(results[:10])

# API: 차트 데이터
@app.route('/api/chart/<collection_name>/<symbol>')
def get_chart_data(collection_name, symbol):
    period = request.args.get('period', '1M')
    df = get_ticker_data(collections[collection_name], symbol, period)
    if df is None:
        return jsonify({'error': 'No data'})
    
    ma_periods = request.args.get('ma', None)
    if ma_periods:
        ma_periods = [int(p) for p in ma_periods.split(',')]
        df = calculate_ma(df, ma_periods)
    
    chart_json = create_candlestick_chart(df, symbol, ma_periods)
    return jsonify({'chart': chart_json, 'data': df.to_dict('records')})

# API: 비교 차트 (정규화 또는 Dual Y)
@app.route('/api/compare_chart')
def get_compare_chart():
    symbols = request.args.get('symbols', '').split(',')
    collection_types = request.args.get('types', '').split(',')
    if len(symbols) < 2:
        return jsonify({'error': 'At least 2 symbols'})
    
    # 간단 예: 등락률 정규화 (3개 이상 시)
    if len(symbols) > 2:
        dfs = []
        for i, sym in enumerate(symbols):
            coll = collections[collection_types[i]]
            df = get_ticker_data(coll, sym[0], '1Y')  # 예: 1Y
            if df is not None:
                df['return'] = (df['close'] / df['close'].iloc[0] - 1) * 100
                dfs.append(df)
        # 병합 및 Plotly
        fig = go.Figure()
        for df, sym in zip(dfs, symbols):
            fig.add_trace(go.Scatter(x=df['date'], y=df['return'], name=sym[0]))
        return jsonify({'chart': fig.to_json()})
    else:
        # Dual Y 예시 (2개)
        return jsonify({'chart': 'Dual Y logic here'})  # 확장 필요

# 관리자: 업데이트 트리거 (백그라운드 실행 예시)
@app.route('/admin/update/<script_name>')
def trigger_update(script_name):
    if script_name in ['kr', 'us', 'index', 'currency']:
        # 실제로는 subprocess로 updaters/*.py 실행
        os.system(f'python updaters/update_{script_name}.py &')
        flash(f'{script_name} update triggered')
    return redirect(url_for('admin'))

# 관리자: ticker_metadata CRUD (예: 추가/편집)
@app.route('/admin/edit_ticker', methods=['POST'])
def edit_ticker():
    ticker = request.form['ticker']
    name = request.form['name']
    market_type = request.form['market_type']
    ticker_metadata.update_one(
        {'ticker': ticker},
        {'$set': {'name': name, 'markettype': market_type, 'isactive': True, 'updatedat': datetime.now()}},
        upsert=True
    )
    flash('Ticker updated')
    return redirect(url_for('admin'))

# 관리자: 리스트 (pagination)
@app.route('/admin/tickers/<market_type>/<int:page>')
def ticker_list(market_type, page=1):
    per_page = 20
    skip = (page - 1) * per_page
    tickers = list(ticker_metadata.find({'markettype': market_type}).skip(skip).limit(per_page))
    total = ticker_metadata.count_documents({'markettype': market_type})
    return jsonify({'tickers': tickers, 'pages': (total + per_page - 1) // per_page, 'current': page})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
