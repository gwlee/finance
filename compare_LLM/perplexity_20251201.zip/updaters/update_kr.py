# 02.mongodb_update_fix.py 기반 분리 버전
import os
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
from pymongo import MongoClient
from concurrent.futures import ThreadPoolExecutor
import time

MONGODB_URI = "mongodb://localhost:27017/"
DATABASE_NAME = "finance_db"
COLLECTION_NAME = "korean_stocks"
MAX_WORKERS = 4

# 한국 주식 티커 리스트 (attachment의 koreanstocks 일부 예시; 전체 로드 필요)
KOREAN_TICKERS = ['000660.KS', '005930.KS', '035420.KS']  # 삼성전자, SK하이닉스 등; 전체는 파일에서

def format_korean_ticker(tickers):
    formatted = []
    for t in tickers:
        if t.endswith('.KS') or t.endswith('.KQ'):
            formatted.append(t)
        elif len(t) == 6 and t.isdigit():
            formatted.append(f"{t}.KS")
        else:
            formatted.append(t)
    return formatted

def get_latest_dates(collection_name, symbols):
    # 최신 날짜 조회 (기존 로직)
    client = MongoClient(MONGODB_URI)
    db = client[DATABASE_NAME]
    collection = db[collection_name]
    pipeline = [{'$match': {'symbol': {'$in': symbols}}}, {'$sort': {'date': -1}}, {'$group': {'_id': '$symbol', 'maxdate': {'$first': '$date'}}}]
    latest_dates = {}
    for doc in collection.aggregate(pipeline, allowDiskUse=True):
        maxdate = doc.get('maxdate')
        if hasattr(maxdate, 'strftime'):
            latest_dates[doc['_id']] = maxdate.strftime('%Y-%m-%d')
        else:
            latest_dates[doc['_id']] = str(maxdate)
    return latest_dates

def fetch_and_insert_ticker(symbol, collection, latest_date_map):
    # 데이터 가져와서 삽입 (기존 로직)
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    latest_date_str = latest_date_map.get(symbol)
    start_date = '1900-01-01'
    if latest_date_str:
        latest_date = datetime.strptime(latest_date_str, '%Y-%m-%d').date()
        start_date = (latest_date + timedelta(days=1)).strftime('%Y-%m-%d')
        if latest_date >= today:
            print(f"{symbol}: up to date")
            return
    print(f"{symbol}: fetching from {start_date}")
    try:
        stock = yf.Ticker(symbol)
        df = stock.history(start=start_date, end=tomorrow.strftime('%Y-%m-%d'))
    except Exception as e:
        print(f"{symbol}: {e}")
        return
    if df.empty:
        return
    df = df.reset_index()
    documents = []
    for _, row in df.iterrows():
        date_obj = pd.to_datetime(row['Date']).to_pydatetime()
        volume_value = int(row['Volume']) if not pd.isna(row['Volume']) else 0
        doc = {
            'symbol': symbol, 'date': date_obj, 'open': float(row['Open']),
            'high': float(row['High']), 'low': float(row['Low']), 'close': float(row['Close']),
            'volume': volume_value
        }
        if 'Dividends' in df.columns:
            doc['dividends'] = float(row['Dividends'])
        if 'Stock Splits' in df.columns:
            doc['stocksplits'] = float(row['Stock Splits'])
        documents.append(doc)
    if not documents:
        return
    client = MongoClient(MONGODB_URI)
    db = client[DATABASE_NAME]
    collection = db[COLLECTION_NAME]
    try:
        collection.insert_many(documents, ordered=False)
        print(f"{symbol}: inserted {len(documents)}")
    except Exception as e:
        print(f"{symbol}: DB error {e}")

if __name__ == '__main__':
    client = MongoClient(MONGODB_URI)
    db = client[DATABASE_NAME]
    collection = db[COLLECTION_NAME]
    # 인덱스 생성
    if 'symbol_1_date_1' not in collection.index_information():
        collection.create_index([('symbol', 1), ('date', 1)], unique=True, name='symbol_date_unique')
    
    tickers = format_korean_ticker(KOREAN_TICKERS)
    latest_dates = get_latest_dates(COLLECTION_NAME, tickers)
    
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = [executor.submit(fetch_and_insert_ticker, symbol, collection, latest_dates) for symbol in tickers]
        for future in futures:
            future.result()
    print("Korean stocks update complete")
